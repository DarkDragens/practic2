﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp17.Windows;


namespace WpfApp17
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        paperEntities db = new paperEntities();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void loginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = loginBox.Text,
                password = passwordBox.Text;
            HandleUser(login, password);
        }

        private void HandleUser(string login, string password)
        {
            var user = db.account.Where(p => p.login == login).FirstOrDefault();
            if (user != null)
            {
                if (user.password == password)
                {
                    NavigteUser(user);
                }
                else
                {
                    Debug.WriteLine($"password should be: {user.password}\n not {password}");
                    MessageBox.Show("incorrect password");
                }
            }
            else
            {
                MessageBox.Show("incorrect login");
            }
        }

        private void NavigteUser(account user)
        {
            var navigationDictionary = new Dictionary<int, string>()
            {
                {1, "Admin"},
                {2, "Maneger"},
                {3, "WorkshopLeader"},
                {4, "WorkshopLeader"},
                {5, "WorkshopLeader"},
                {6, "WorkshopLeader"},
                {7, "WorkshopLeader"},
                {8, "WorkshopWorker"},
                {9, "WorkshopWorker"},
                {10, "WorkshopWorker"},
                {11, "WorkshopWorker"},
                {12, "WorkshopWorker"},
            };

            try
            {
                switch (navigationDictionary[user.role_id])
                {
                    case "Admin":
                        var admin = new Admin(user);
                        admin.Show();
                        this.Close();
                        break;
                    case "Maneger":
                        var maneger = new Maneger(user);
                        maneger.Show();
                        this.Close();
                        break;
                    case "WorkshopLeader":
                        var workshopLeader = new WorkshopLeader(user);
                        workshopLeader.Show();
                        this.Close();
                        break;
                    case "WorkshopWorker":
                        var workshopWorker = new WorkshopWorker(user);
                        workshopWorker.Show();
                        this.Close();
                        break;
                    default:
                        Debug.WriteLine($"unknown role walue:{navigationDictionary[user.role_id]}");
                        break;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Debug.WriteLine(ex.Message);
            }
        }
    }
}
