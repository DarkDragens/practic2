﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;
using System.Data;
using System.Diagnostics;
using System.Data.Objects.SqlClient;

namespace WpfApp17.Windows
{
    /// <summary>
    /// Логика взаимодействия для Accounts.xaml
    /// </summary>
    public partial class Accounts : Window
    {
        private paperEntities db = new paperEntities();

        public Accounts()
        {
            InitializeComponent();
            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            try
            {
                var data = (from acc in db.account
                            join role in db.role on acc.role_id equals role.id
                            join person in db.person on acc.person_id equals person.id
                            join name in db.name on person.name_id equals name.id
                            join surname in db.surname on person.surname_id equals surname.id
                            select new
                            {
                                login = acc.login,
                                password = acc.password,
                                Role = role.title,
                                Person_id = person.id,
                                Name = name.title,
                                Surname = surname.title,
                                BankCard = person.bank_card_number,
                                Passport = person.passport_number
                            }).ToList();

                dg.ItemsSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = SearchBox.Text.Trim();
            var searchData = db.account.Where(acc => acc.login.Contains(searchTerm)).ToList();

            if (searchData.Any())
            {
                dg.ItemsSource = searchData;
            }
            else
            {
                MessageBox.Show("No results found.", "Search", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void dg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (dg.SelectedItem != null)
                {
                    dynamic selectedAccount = dg.SelectedItem;
                    loginBox.Text = selectedAccount.login;
                    passwordBox.Text = selectedAccount.password;
                    roleBox.Text = selectedAccount.Role;
                    personBox.Text = Convert.ToString(selectedAccount.Person_id);
                    nameBox.Text = selectedAccount.Name;
                    surnameBox.Text = selectedAccount.Surname;
                    bankCardBox.Text = Convert.ToString(selectedAccount.BankCard);
                    passportBox.Text = Convert.ToString(selectedAccount.Passport);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            string login = loginBox.Text.Trim(),
                password = passwordBox.Text.Trim(),
                role = roleBox.Text.Trim(),
                person = personBox.Text.Trim(),
                name = nameBox.Text.Trim(),
                surname = surnameBox.Text.Trim(),
                bankCard = bankCardBox.Text.Trim(),
                passportNumber = passportBox.Text.Trim();

            if (db.account.FirstOrDefault(p => p.login == login) == null)
            {
                CreateAccount(login, password, role, name, surname, person, bankCard, passportNumber);
            }
            else
            {
                UpdateAccount(login, password, role, name, surname);
            }

            LoadDataGrid();
        }

        private int GetOrAddNameId(string name)
        {
            var nameEntity = db.name.FirstOrDefault(n => n.title == name);

            if (nameEntity == null)
            {
                nameEntity = new name { title = name };
                db.name.Add(nameEntity);
            }

            return nameEntity.id;
        }

        private int GetOrAddSurnameId(string name)
        {
            var nameEntity = db.surname.FirstOrDefault(n => n.title == name);

            if (nameEntity == null)
            {
                nameEntity = new surname { title = name };
                db.surname.Add(nameEntity);
                db.SaveChanges();
            }

            return nameEntity.id;
        }

        private void CreateAccount(string login, string password, string role, string name, string surname, string personId, string bankCard, string passport)
        {
            int nameId = GetOrAddNameId(name);
            int surnameId = GetOrAddSurnameId(surname);

            if (string.IsNullOrEmpty(personId) || db.person.Where(p => p.id == int.Parse(personId)).FirstOrDefault() == null)
            {
                int personIdValue = CreatePerson(nameId, surnameId, passport, bankCard);
                personId = Convert.ToString(personIdValue);
            }

            var newAccount = new account
            {
                login = login,
                password = password,
                role_id = GetRoleId(role) ?? 0,
                person_id = int.Parse(personId),
            };

            db.account.Add(newAccount);
            db.SaveChanges();

            MessageBox.Show("User created successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private int CreatePerson(int nameId, int surnameId, string passport, string bankCard)
        {
            person newPerson = new person()
            {
                name_id = nameId,
                surname_id = surnameId,
                passport_number = long.Parse(passport),
                bank_card_number = long.Parse(bankCard),
            };

            db.person.Add(newPerson);
            db.SaveChanges();

            return newPerson.id;
        }

        private void UpdateAccount(string login, string password, string role, string name, string surname)
        {
            var existingUser = db.account.FirstOrDefault(acc => acc.login == login);

            if (existingUser != null)
            {
                existingUser.password = password;
                existingUser.role_id = GetRoleId(role) ?? 0;

                var nameId = GetOrAddNameId(name);
                var surnameId = GetOrAddSurnameId(surname);

                var personEntity = db.person.Where(p => p.id == existingUser.person_id).FirstOrDefault();

                if (personEntity != null)
                {
                    personEntity.name_id = nameId;
                    personEntity.surname_id = surnameId;
                }

                db.SaveChanges();

                MessageBox.Show("User account updated successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void UpdateNameAndSurname(string name, string surname, int personId)
        {
            var nameEntity = db.name.FirstOrDefault(n => n.title == name);
            if (nameEntity != null)
            {
                db.Entry(nameEntity).State = EntityState.Modified;
            }
            else
            {
                db.name.Add(new name { title = name });
            }

            var surnameEntity = db.surname.FirstOrDefault(s => s.title == surname);
            if (surnameEntity != null)
            {
                db.Entry(surnameEntity).State = EntityState.Modified;
            }
            else
            {
                db.surname.Add(new surname { title = surname });
            }

            db.SaveChanges();

            var person = db.person.FirstOrDefault(p => p.id == personId);
            if (person != null)
            {
                person.name_id = db.name.FirstOrDefault(n => n.title == name)?.id ?? 0;
                person.surname_id = db.surname.FirstOrDefault(s => s.title == surname)?.id ?? 0;

                db.SaveChanges();
            }
        }

        private int? GetRoleId(string role)
        {
            return db.role.FirstOrDefault(r => r.title == role)?.id;
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            var user = db.account.FirstOrDefault(p => p.login == loginBox.Text);

            if (user != null)
            {
                db.account.Remove(user);
                db.SaveChanges();
                MessageBox.Show("User account deleted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("User not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            LoadDataGrid();
        }
    }
}